CREATE FUNCTION pretty_display_string (str integer) RETURNS text
	LANGUAGE sql
AS $$
  select '''' ||  str || ''''
$$
