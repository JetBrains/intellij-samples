CREATE FUNCTION pretty_display_string (str text) RETURNS text
	LANGUAGE sql
AS $$
  select upper(str)
$$
