CREATE VIEW animal_sighting AS
SELECT sp.name,
    si."time",
    si.date
   FROM animals.species sp,
    animals.sighting si
  WHERE (si.species_id = sp.id)