CREATE FUNCTION archive () RETURNS trigger
	LANGUAGE plpgsql
AS $$
BEGIN
    DELETE
    FROM animals.sighting
    WHERE sighting.date < now() - INTERVAL '180 days';
  RETURN NEW;
  END;
$$
