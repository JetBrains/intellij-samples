CREATE TRIGGER new_sighting
BEFORE INSERT ON animals.sighting
FOR EACH ROW EXECUTE PROCEDURE animals.archive()